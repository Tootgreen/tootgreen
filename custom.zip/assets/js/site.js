// Mouse reveal background effect
(function () {
  function initMouseReveal() {
    if (document.getElementById('mouse-reveal')) {
      return;
    }

    var reveal = document.createElement('div');
    reveal.id = 'mouse-reveal';
    document.body.appendChild(reveal);

    var mouseX = 0;
    var mouseY = 0;
    var currentX = 0;
    var currentY = 0;
    var currentRadius = 0;
    var targetRadius = 0;
    var hasMouse = false;

    document.addEventListener('mousemove', function (e) {
      mouseX = e.clientX;
      mouseY = e.clientY;

      if (!hasMouse) {
        currentX = mouseX;
        currentY = mouseY;
        hasMouse = true;
      }

      targetRadius = 160;
    });

    document.addEventListener('mouseleave', function () {
      targetRadius = 0;
    });

    function animate() {
      if (hasMouse) {
        currentX += (mouseX - currentX) * 0.12;
        currentY += (mouseY - currentY) * 0.12;
        currentRadius += (targetRadius - currentRadius) * 0.12;

        var maskValue =
          'radial-gradient(circle ' + currentRadius + 'px at ' + currentX + 'px ' + currentY + 'px, rgba(0,0,0,1) 0%, rgba(0,0,0,0) 70%)';

        reveal.style.webkitMaskImage = maskValue;
        reveal.style.maskImage = maskValue;
      }

      requestAnimationFrame(animate);
    }

    animate();
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initMouseReveal);
  } else {
    initMouseReveal();
  }
})();
